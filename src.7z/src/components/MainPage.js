import React from 'react';

function MainPage(props) {
    return (
        <div>
        <h1 align= "center">
            Welcome to Shopping Zone
        </h1>
        </div>
    );
}

export default MainPage;