import React, { Component } from 'react';

class Welcome extends Component {
    render() {
        return (
          
          <div align = "center">
          <h1>
             Welcome to the Shopping Cart
             </h1>   
            </div>
        )
    }
}

export default Welcome;

